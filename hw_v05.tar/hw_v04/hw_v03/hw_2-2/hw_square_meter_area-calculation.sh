#!/bin/bash

echo "hello $1 $2"
